import unittest
from ledger import total

class LedgerTests(unittest.TestCase):
    def test_total(self):
        self.assertEqual(total([{"date": "2026-09-01", "amount": 10}, {"date": "2026-10-01", "amount": 20}]), 30)

if __name__ == "__main__":
    unittest.main()
