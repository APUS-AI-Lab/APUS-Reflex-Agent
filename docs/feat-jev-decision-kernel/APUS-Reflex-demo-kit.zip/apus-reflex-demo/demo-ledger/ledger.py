"""Synthetic ledger; add monthly totals during the demo."""

def total(entries):
    return sum(entry["amount"] for entry in entries)
