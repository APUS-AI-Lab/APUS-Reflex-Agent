"""Run real unittest tests between synthetic progress lines; keep the real exit code."""
import argparse
from pathlib import Path
import subprocess
import sys

parser = argparse.ArgumentParser()
parser.add_argument("--unittest", action="store_true", required=True)
parser.parse_args()
for i in range(180):
    print(f"Synthetic progress before tests {i:03d}: completed sample validation", flush=True)
result = subprocess.run([sys.executable, "-m", "unittest", "-v"], cwd=Path(__file__).parent, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
print(result.stdout, end="", flush=True)
for i in range(180):
    print(f"Synthetic progress after tests {i:03d}: completed sample validation", flush=True)
sys.exit(result.returncode)
