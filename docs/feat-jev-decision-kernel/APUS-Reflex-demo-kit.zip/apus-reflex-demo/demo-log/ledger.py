"""Synthetic order calculation with an intentional refund-sign defect."""

def net(gross, discount, refund):
    return gross - discount + refund
