import unittest
from ledger import net

class LedgerTests(unittest.TestCase):
    def test_no_refund(self):
        self.assertEqual(net(100, 10, 0), 90)
    def test_refund(self):
        self.assertEqual(net(100, 10, 20), 70)
    def test_empty(self):
        self.assertEqual(net(0, 0, 0), 0)

if __name__ == "__main__":
    unittest.main()
